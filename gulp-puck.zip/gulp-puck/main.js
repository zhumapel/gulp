document.addEventListener('DOMContentLoaded', function() {
    const toggleButton = document.querySelector('.navigation__toggle');
    const menu = document.querySelector('.navigation__menu');

    if (toggleButton && menu) {
        toggleButton.addEventListener('click', function() {
            menu.classList.toggle('open');

            if (menu.classList.contains('open')) {
                menu.style.maxHeight = menu.scrollHeight + 'px';
            } else {
                menu.style.maxHeight = '0';
            }
        });
    }
});