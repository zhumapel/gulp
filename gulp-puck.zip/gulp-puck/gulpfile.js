const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const cleanCSS = require('gulp-clean-css');
const htmlmin = require('gulp-htmlmin');
const browserSync = require('browser-sync').create();
const fs = require('fs');
const path = require('path');

// Объект paths содержит пути к исходным и целевым файлам и папкам
const paths = {
    styles: {
        src: 'src/scss/**/*.scss', // Путь к исходным файлам SCSS
        dest: 'dist/css' // Путь к целевой папке для скомпилированных CSS
    },
    html: {
        src: 'src/*.html', // Путь к исходным файлам HTML
        dest: 'dist' // Путь к целевой папке для HTML файлов
    },
    js: {
        src: 'src/js/**/*.js', // Путь к исходным файлам JavaScript
        dest: 'dist/js' // Путь к целевой папке для JavaScript файлов
    },
    images: {
        src: 'src/images/**/*', // Путь к исходным изображениям
        dest: 'dist/images' // Путь к целевой папке для изображений
    },
    fonts: {
        src: 'src/fonts/**/*', // Путь к исходным файлам шрифтов
        dest: 'dist/fonts' // Путь к целевой папке для шрифтов
    }
};

// Функция для очистки целевых папок перед сборкой
function clean() {
    return new Promise((resolve, reject) => {
        if (fs.existsSync(paths.styles.dest)) {
            const files = fs.readdirSync(paths.styles.dest);
            for (const file of files) {
                if (file !== 'style.scss') {
                    fs.unlinkSync(path.join(paths.styles.dest, file));
                }
            }
        }
        resolve();
    });
}

// Функция для создания целевых папок перед сборкой
function createDistFolder() {
    return new Promise((resolve, reject) => {
        fs.mkdir(paths.styles.dest, { recursive: true }, err => {
            if (err) reject(err);
            else {
                fs.mkdir(paths.js.dest, { recursive: true }, err => {
                    if (err) reject(err);
                    else {
                        fs.mkdir(paths.images.dest, { recursive: true }, err => {
                            if (err) reject(err);
                            else {
                                fs.mkdir(paths.fonts.dest, { recursive: true }, err => {
                                    if (err) reject(err);
                                    else {
                                        resolve();
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    });
}

// Функция для компиляции и минификации стилей SCSS
function styles() {
    return gulp
        .src(paths.styles.src)
        .pipe(sass().on('error', sass.logError))
        .pipe(cleanCSS())
        .pipe(gulp.dest(paths.styles.dest))
        .pipe(browserSync.stream());
}

// Функция для минификации HTML
function html() {
    return gulp
        .src(paths.html.src)
        .pipe(htmlmin({ collapseWhitespace: true }))
        .pipe(gulp.dest(paths.html.dest))
        .pipe(browserSync.stream());
}

// Функция для перемещения JavaScript файлов
function scripts() {
    return gulp
        .src(paths.js.src)
        .pipe(gulp.dest(paths.js.dest))
        .pipe(browserSync.stream());
}

// Функция для перемещения файла index.html в целевую папку
function moveIndex() {
    return gulp
        .src('src/index.html', { allowEmpty: true })
        .pipe(gulp.dest(paths.html.dest))
        .pipe(browserSync.stream());
}

// Функция для перемещения файла main.js в целевую папку
function moveMainJs() {
    return gulp
        .src('src/js/main.js', { allowEmpty: true })
        .pipe(gulp.dest(paths.js.dest))
        .pipe(browserSync.stream());
}

// Функция для копирования стилей из папки src в dist
function copyStyles() {
    return gulp
        .src('src/css/**/*.css')
        .pipe(gulp.dest('dist/css'))
        .pipe(browserSync.stream());
}

function serve() {
    browserSync.init({
        server: {
            baseDir: './dist'
        }
    });

    gulp.watch('src/**/*', gulp.series(clean, gulp.parallel(styles, html, scripts, moveIndex, moveMainJs, copyStyles))).on('change', browserSync.reload);
}

// Экспорт функций для доступа из командной строки
exports.clean = clean;
exports.styles = styles;
exports.html = html;
exports.scripts = scripts;
exports.moveIndex = moveIndex;
exports.moveMainJs = moveMainJs;
exports.serve = serve;
exports.default = gulp.series(
    createDistFolder,
    clean,
    gulp.parallel(styles, html, scripts, moveIndex, moveMainJs),
    serve
);